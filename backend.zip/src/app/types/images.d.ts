declare module "*.jpg";
declare module "*.jpeg";
declare module "*.webp";
