export interface TContent {
  aboutUs?: string;
  termsAndConditions?: string;
  privacyPolicy?: string;
  support?: string;
}
