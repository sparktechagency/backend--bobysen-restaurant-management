export const RessearchAbleFields = ["name", "owner", "address"];

export const restaurantExcludeFields = [
  "searchTerm",
  "page",
  "limit",
  "latitude",
  "longitude",
];
