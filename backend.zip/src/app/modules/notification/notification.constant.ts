export const messages = {
  booking: "You have successfully booked a table",
  bookingForOwner: "An user booked a table",
  cancelled: "Your Booking has been cancelled",
  payment:
    "You have received a payment from the admin. Please check your payment history page for details.",
};
