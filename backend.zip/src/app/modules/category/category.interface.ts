export interface Icategory {
  name: string;
  isActive: boolean;
  isDeleted: boolean;
}
