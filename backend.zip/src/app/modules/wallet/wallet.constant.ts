export const WalletSearchableFields: string[] = ["restaurant", "owner"];
