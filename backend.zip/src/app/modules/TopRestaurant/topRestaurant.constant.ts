export const topRestaurantSearchableFileds = [
  "restaurant.name",
  "restaurant.address",
];
export const topRestaurantExcludeFileds = [
  "searchTerm",
  "page",
  "limit",
  "latitude",
  "longitude",
];
