export type QueryObject = {
  [key: string]: any;
};
